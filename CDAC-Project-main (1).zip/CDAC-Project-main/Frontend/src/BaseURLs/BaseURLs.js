export const BUS_SERVICE_API_BASE_URL = "https://localhost:5050";
