﻿namespace BusReservationNET.DTO
{
    public class UserDTO
    {
        public string Username { get; set; }
        public string Contact { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string Password { get; set; }
    }
}
