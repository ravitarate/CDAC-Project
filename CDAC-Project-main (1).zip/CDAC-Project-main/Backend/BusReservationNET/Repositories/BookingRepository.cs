﻿namespace BusReservationNET.Repositories
{
    public class BookingRepository : IBookingRepository
    {
    }
}
