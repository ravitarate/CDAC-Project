﻿namespace BusReservationNET.Repositories
{
    public interface IBookingRepository
    {
    }
}
